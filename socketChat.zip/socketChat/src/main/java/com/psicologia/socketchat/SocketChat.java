package com.psicologia.socketchat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SocketChat extends Observable implements Runnable {

    private int puerto;
    
    public SocketChat(int puerto){
        this.puerto = puerto;
    }
    
    @Override
    public void run() {
        ServerSocket servidor = null;
        Socket sc = null;
        DataInputStream in;
        DataOutputStream out;

        try {
            servidor = new ServerSocket(puerto);
            System.out.println("Servidor Iniciado");

            while (true) {

                sc = servidor.accept();

                System.out.println("Cliente Conectado");
                in = new DataInputStream(sc.getInputStream());

                String mensaje = in.readUTF();

                System.out.println(mensaje);
                
                this.setChanged();
                this.notifyObservers(mensaje);
                this.clearChanged();

                sc.close();
                System.out.println("Cliente Desconectado");
            }
        } catch (IOException ex) {
            Logger.getLogger(SocketChat.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
